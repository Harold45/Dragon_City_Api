// app.js

// URLs de la API
const apiUrl = "http://localhost:3306/dragons";

// Obtener todos los dragones
function getDragons() {
  fetch(apiUrl)
    .then((response) => response.json())
    .then((data) => {
      const dragonsContainer = document.getElementById("dragonsContainer");
      dragonsContainer.innerHTML = ''; // Limpiar el contenedor antes de cargar los datos

      data.forEach((dragon) => {
        const dragonElement = document.createElement("div");
        dragonElement.classList.add("dragon");
        dragonElement.innerHTML = `
          <h3>${dragon.name}</h3>
          <p>Tipo: ${dragon.type}</p>
          <p>Nivel: ${dragon.level}</p>
          <p>Habilidades: ${dragon.abilities}</p>
          <button onclick="getDragonById(${dragon.id})">Ver Detalles</button>
          <button onclick="deleteDragon(${dragon.id})">Eliminar</button>
        `;
        dragonsContainer.appendChild(dragonElement);
      });
    })
    .catch((error) => console.error("Error al obtener los dragones:", error));
}

// Obtener un dragón específico por ID
function getDragonById(id) {
  fetch(`${apiUrl}/${id}`)
    .then((response) => response.json())
    .then((data) => {
      const dragonDetails = document.getElementById("dragonDetails");
      dragonDetails.innerHTML = `
        <h3>${data.name}</h3>
        <p>Tipo: ${data.type}</p>
        <p>Nivel: ${data.level}</p>
        <p>Habilidades: ${data.abilities}</p>
      `;
    })
    .catch((error) => console.error("Error al obtener el dragón:", error));
}

// Función para crear un nuevo dragón
async function createDragon(event) {
  event.preventDefault();
  const name = document.getElementById("name").value;
  const type = document.getElementById("type").value;
  const level = document.getElementById("level").value;
  const abilities = document.getElementById("abilities").value;

  const response = await fetch(apiUrl, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, type, level, abilities })
  });

  if (response.ok) {
    alert("Dragón creado con éxito");
    getDragons(); // Recargar los dragones
  } else {
    alert("Error al crear el dragón");
  }
}

// Función para actualizar un dragón
async function updateDragon(event) {
  event.preventDefault();
  const id = document.getElementById("updateId").value;
  const name = document.getElementById("updateName").value;
  const type = document.getElementById("updateType").value;
  const level = document.getElementById("updateLevel").value;
  const abilities = document.getElementById("updateAbilities").value;

  const response = await fetch(`${apiUrl}/${id}`, {
    method: "PUT",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ name, type, level, abilities })
  });

  if (response.ok) {
    alert("Dragón actualizado con éxito");
    getDragons(); // Recargar los dragones
  } else {
    alert("Error al actualizar el dragón");
  }
}

// Función para eliminar un dragón
async function deleteDragon(id) {
  const response = await fetch(`${apiUrl}/${id}`, {
    method: "DELETE",
  });

  if (response.ok) {
    alert("Dragón eliminado con éxito");
    getDragons(); // Recargar los dragones
  } else {
    alert("Error al eliminar el dragón");
  }
}

// Eventos
document.getElementById("createDragonForm").addEventListener("submit", createDragon);
document.getElementById("updateDragonForm").addEventListener("submit", updateDragon);

// Cargar los dragones al iniciar
document.addEventListener("DOMContentLoaded", getDragons);
