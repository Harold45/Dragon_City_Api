const { DataTypes } = require("sequelize");
const sequelize = require("../db");

const Dragon = sequelize.define("Dragon", {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true,
  },
  name: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  type: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  level: {
    type: DataTypes.INTEGER,
    defaultValue: 1,
  },
  abilities: {
    type: DataTypes.TEXT,
    allowNull: false,
  },
});

module.exports = Dragon;
