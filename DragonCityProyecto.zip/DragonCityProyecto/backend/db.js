const { Sequelize } = require("sequelize");

// Configuración de conexión a MySQL
const sequelize = new Sequelize("dragoncity", "root", "12345", {
  host: "localhost",     // Cambia esto si el servidor no es localhost
  dialect: "mysql",      // Tipo de base de datos
  port: 3306,            // Asegúrate de usar el puerto correcto
});

(async () => {
  try {
    await sequelize.authenticate();
    console.log("Conexión a MySQL establecida correctamente.");
  } catch (error) {
    console.error("No se pudo conectar a MySQL:", error);
  }
})();

module.exports = sequelize;
