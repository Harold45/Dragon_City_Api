const express = require("express");
const app = express();
const sequelize = require('./db');
const dragonRoutes = require('./routes/dragonRoutes');
const bodyParser = require("body-parser");
const cors = require("cors");
const { Dragon } = require("./models"); // Importa el modelo Dragon

// Middleware
app.use(cors()); // Habilita CORS para solicitudes desde el cliente
app.use(bodyParser.json()); // Permite que el servidor entienda solicitudes JSON

// Ruta de prueba
app.get("/", (req, res) => {
  res.send("API de Dragon City funcionando correctamente.");
});

// Obtener todos los dragones
app.get("/dragons", async (req, res) => {
  try {
    const dragons = await Dragon.findAll();
    res.json(dragons);
  } catch (error) {
    res.status(500).json({ message: "Error al obtener los dragones" });
  }
});

// Obtener un dragón por ID
app.get("/dragons/:id", async (req, res) => {
  try {
    const dragon = await Dragon.findByPk(req.params.id);
    if (dragon) {
      res.json(dragon);
    } else {
      res.status(404).json({ message: "Dragón no encontrado" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error al obtener el dragón" });
  }
});

// Crear un nuevo dragón
app.post("/dragons", async (req, res) => {
  try {
    const { name, type, level, abilities } = req.body;
    const dragon = await Dragon.create({ name, type, level, abilities });
    res.status(201).json(dragon);
  } catch (error) {
    res.status(500).json({ message: "Error al crear el dragón" });
  }
});

// Actualizar un dragón
app.put("/dragons/:id", async (req, res) => {
  try {
    const { name, type, level, abilities } = req.body;
    const dragon = await Dragon.findByPk(req.params.id);
    if (dragon) {
      dragon.name = name;
      dragon.type = type;
      dragon.level = level;
      dragon.abilities = abilities;
      await dragon.save();
      res.json(dragon);
    } else {
      res.status(404).json({ message: "Dragón no encontrado" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error al actualizar el dragón" });
  }
});

// Eliminar un dragón
app.delete("/dragons/:id", async (req, res) => {
  try {
    const dragon = await Dragon.findByPk(req.params.id);
    if (dragon) {
      await dragon.destroy();
      res.json({ message: "Dragón eliminado con éxito" });
    } else {
      res.status(404).json({ message: "Dragón no encontrado" });
    }
  } catch (error) {
    res.status(500).json({ message: "Error al eliminar el dragón" });
  }
});

// Iniciar el servidor
const PORT = process.env.PORT || 3306;
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});