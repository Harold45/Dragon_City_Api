// routes/dragons.js
const express = require("express");
const router = express.Router();


// Ruta GET para obtener todos los dragones
router.get("/", async (req, res) => {
  try {
    const dragons = await Dragon.findAll(); // Obtiene todos los dragones
    res.json(dragons); // Devuelve los dragones en formato JSON
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener los dragones" });
  }
});

// Ruta GET para obtener un dragón específico
router.get("/:id", async (req, res) => {
  const { id } = req.params; // Obtiene el ID del dragón de la URL
  try {
    const dragon = await Dragon.findByPk(id); // Busca el dragón por su ID
    if (!dragon) {
      return res.status(404).json({ error: "Dragón no encontrado" });
    }
    res.json(dragon); // Devuelve el dragón en formato JSON
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al obtener el dragón" });
  }
});

// Ruta POST para crear un nuevo dragón
router.post("/", async (req, res) => {
  const { name, type, level, abilities } = req.body;
  try {
    const dragon = await Dragon.create({ name, type, level, abilities });
    res.status(201).json(dragon); // Devuelve el dragón creado
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al crear el dragón" });
  }
});

// Ruta PUT para actualizar un dragón
router.put("/:id", async (req, res) => {
  const { id } = req.params;
  const { name, type, level, abilities } = req.body;
  try {
    const dragon = await Dragon.findByPk(id);
    if (!dragon) {
      return res.status(404).json({ error: "Dragón no encontrado" });
    }
    await dragon.update({ name, type, level, abilities });
    res.json(dragon); // Devuelve el dragón actualizado
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al actualizar el dragón" });
  }
});

// Ruta DELETE para eliminar un dragón
router.delete("/:id", async (req, res) => {
  const { id } = req.params;
  try {
    const dragon = await Dragon.findByPk(id);
    if (!dragon) {
      return res.status(404).json({ error: "Dragón no encontrado" });
    }
    await dragon.destroy(); // Elimina el dragón
    res.status(204).send(); // Devuelve un código de estado 204 (sin contenido)
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al eliminar el dragón" });
  }
});

module.exports = router;
